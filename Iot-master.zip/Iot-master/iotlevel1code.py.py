import serial#Serial imported for Serial communication
import time
import sqlite3
con=sqlite3.connect('rfid.db')
cur=con.cursor()
ArduinoUnoSerial = serial.Serial('com5',9600)
time.sleep(2)#Create Serial port object called ArduinoUnoSerialData time.sleep(2)                                                             #wait for 2 secounds for the communication to get established
#tagread=ArduinoUnoSerial.readline()#read the serial data and print it as line
#print(tagread)
time.sleep(2)
print("You have new message from Arduino")
Strings= ["12002A25918C", "12002A24362A", "09002897CC7A","09002897D462", "12002A02043E", "12002A59B7D6","090028543540","12002A71E9A0","12002A735B10","12002A804AF2","12002A3BFEFD","13000333D6F5","09002897D365","09002897D563","130007583E72"];
while 1:
    print("*****************WELCOME****************")
    print("_____ENTER_____")
    print("1.Locate")
    print("2.If you have brought home a new thing")
    print("3.I want to throw this thing")
    print("4.Display where he things are")
    inp=input()
    if inp=='1':
         cur.execute(""" CREATE TABLE IF NOT EXISTS things(tagid text,name text,location integer)""")
         tagid=Strings[int(input())]
         name=input("Enter name: ")
         location=int(input("Enter Location:"))
         li=(tagid,name,location)
         ins='INSERT INTO things VALUES(?,?,?)'
         cur.execute(ins,li)
         cur.execute('SELECT * FROM things')
         print(cur.fetchall())
         print("Your book has been successfully inserted at %s"%(location))
         con.commit()
         
    if inp=='2':
         name1=input("Enter the name of the thing you want to find")
         lis=[name1]
         cur.execute("SELECT location FROM things where name =(?)",lis)
         print("Your thing has been found at compartment which is shown by this led which is glowing")
         a=cur.fetchall()
         b=int(a[0][0])
         print(b)
         con.commit()
         if b==1:
             ArduinoUnoSerial.write(b'1')
             time.sleep(10)   
         elif b==2:
             ArduinoUnoSerial.write(b'2')
             time.sleep(10)
         else:
             ArduinoUnoSerial.write(b'3')
             time.sleep(10)
         print ("LED turned ON AT COMPARTMENT"+str(b))         
         time.sleep(1)
    if inp=='3':
        name2=input("Enter the name of the thing you want to delete")
        lisd=[name2]
        cur.execute("DELETE FROM things where name=(?)",lisd)
        print("book has been deleted")
        con.commit()
    if inp=='4':
        cur.execute("SELECT * FROM things")
        sel=cur.fetchall()
        print("tag          book          compartment")
        for i in sel:
            print(i[0],end=" ")
            print(i[1],end=" ")
            print(i[2],end=" ")
            print()
    if (inp== 'fine and you'):break;




'''import sqlite3
li=("priyanka","polina")
grade=[('Venkata','Narayana'),('Jaya','Sravanthi')]
con=sqlite3.connect('students.db')
cur=con.cursor()
#cur.execute(""" CREATE TABLE student(first text,last text)""")
ins='INSERT INTO student VALUES(?,?)'
cur.execute(ins,li)
#cur.execute('SELECT * FROM student')
#cur.executemany('INSERT INTO student VALUES(?,?)',grade)
#print(cur.fetchone())
#print(cur.fetchall())
#print(cur.fetchmany(7)) #fetches one row from the given cursor (Active Set)
#print(cur.fetchone())
#print(cur.fetchall()) #fetches all the remaining records.
#for i in cur:
    #print(i[0])
#print(cur.fetchall())
#cur.execute('SELECT name from sqlite_master where type="table" ')
#cur.execute("select last from student where first=='Swarna'")
#cur.execute('select * from students order by DESC')
#print(cur.fetchall())

 #connection commit.
con.close()
#To get the values of a particular row.'''



