import serial
ard=serial.Serial('com5',9600)
stri=ard.readline()
print(stri)
